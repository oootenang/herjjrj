module.exports = {
modul: {
fs: require('fs'),
baileys: require('@adiwajshing/baileys'), 
boom: require('@hapi/boom'),
chalk: require('chalk'),
path: require('path'),
process: require('process'),
}
}